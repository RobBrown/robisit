"use strict";

const MEET_PATTERN = "https://meet.google.com/*";
// Standard Meet meeting code, e.g. /abc-defg-hij or /meet/abc-defg-hij
const MEETING_CODE_PATH = /^\/(?:meet\/)?[a-z]{3}-[a-z]{4}-[a-z]{3}$/;
const TITLE_PREFIX = "Meet - ";

function isMeetingTab(tab) {
  if (typeof tab.url !== "string") return false;
  let url;
  try {
    url = new URL(tab.url);
  } catch (e) {
    return false;
  }
  return url.origin === "https://meet.google.com" && MEETING_CODE_PATH.test(url.pathname);
}

function displayTitle(title) {
  const text = typeof title === "string" ? title : "";
  return text.startsWith(TITLE_PREFIX) ? text.slice(TITLE_PREFIX.length) : text;
}

async function setMuted(tabId, muted, checkbox) {
  try {
    const tab = await chrome.tabs.update(tabId, { muted });
    checkbox.checked = tab.mutedInfo.muted;
  } catch (e) {
    try {
      const tab = await chrome.tabs.get(tabId);
      checkbox.checked = tab.mutedInfo.muted;
    } catch (e2) {
      checkbox.checked = !muted;
      checkbox.disabled = true;
    }
  }
}

// Builds one row. Titles are only ever assigned via textContent.
function renderRow(tab) {
  const row = document.createElement("li");
  row.className = "row";

  const title = document.createElement("span");
  title.className = "title";
  title.textContent = displayTitle(tab.title);
  title.title = title.textContent;

  const label = document.createElement("label");
  label.className = "toggle";

  const checkbox = document.createElement("input");
  checkbox.type = "checkbox";
  checkbox.setAttribute("role", "switch");
  checkbox.checked = Boolean(tab.mutedInfo && tab.mutedInfo.muted);
  checkbox.addEventListener("change", () => {
    setMuted(tab.id, checkbox.checked, checkbox);
  });

  const labelText = document.createElement("span");
  labelText.textContent = "Muted";

  label.append(checkbox, labelText);
  row.append(title, label);
  return row;
}

async function main(list, empty) {
  const tabs = (await chrome.tabs.query({ url: MEET_PATTERN })).filter(isMeetingTab);
  if (tabs.length === 0) {
    empty.hidden = false;
    return;
  }
  list.replaceChildren(...tabs.map(renderRow));
}

const listEl = document.getElementById("tabs");
const emptyEl = document.getElementById("empty");
if (listEl && emptyEl) {
  main(listEl, emptyEl);
}
